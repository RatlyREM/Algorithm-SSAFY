const serviceKey =
  "QIwhnv5m5KXaXU9cFxE4rud%2FrEU0h8D2qAJnQ0r82sZkmTSJnI7p6GGvNbNgIA%2FYxSVqiYLBckspxPRElQ7ltQ%3D%3D";
// const kakaoKey = "----- 발급받은 KAKAO API KEY를 입력하세요 -----";
