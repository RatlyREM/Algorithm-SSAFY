package com.ssafy.enjoytrip.model.dao;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ssafy.enjoytrip.model.EnjoyTripDto;
import com.ssafy.util.DBUtil;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class EnjoyTripDaoImpl implements EnjoyTripDao {
	
	private static EnjoyTripDao enjoytripdao = new EnjoyTripDaoImpl();
	//Singleton
	
	private EnjoyTripDaoImpl() {
	}
	
	
	public static EnjoyTripDao getEnjoytripdao() {
		return enjoytripdao;
	}


	public static void setEnjoytripdao(EnjoyTripDao enjoytripdao) {
		EnjoyTripDaoImpl.enjoytripdao = enjoytripdao;
	}


	@Override
	public void regist(EnjoyTripDto enjoytripdto) {
		// TODO Auto-generated method stub

	}

	@Override
	public List<EnjoyTripDto> list(String s1, String s2, String s3) throws Exception {
		List<EnjoyTripDto> list = new ArrayList<>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		String area = s1;
		String content = s2;
		String search = s3;
		
		try {
			conn = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			
			sql.append("select distinct addr1, title, first_image, latitude, longitude \n");
			sql.append("from attraction_info ai join sido \n");
			//sql.append("where ai.sido_code=? and content_type_id=? ");
			sql.append("WHERE ai.sido_code=? AND content_type_id=? AND title LIKE ?");
			pstmt = conn.prepareStatement(sql.toString());
			
			pstmt.setString(1, area); // 첫 번째 ?에 area 변수의 값을 바인딩합니다.
			pstmt.setString(2, content);
			pstmt.setString(3, "%" + search + "%");
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				EnjoyTripDto dto = new EnjoyTripDto();
				dto.setAddr1(rs.getString("addr1"));
				dto.setTitle(rs.getString("title"));
				dto.setFirst_image(rs.getString("first_image"));
				dto.setLatitude(rs.getString("latitude"));
				dto.setLongitude(rs.getString("longitude"));
				
				
				list.add(dto);
			}
			
		} finally {
			DBUtil.close(rs, pstmt, conn);
		}
		
		return list;
		
		
		
	}

	@Override
	public EnjoyTripDto view(String code) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void modify(EnjoyTripDto enjoytripdto) {
		// TODO Auto-generated method stub

	}

	@Override
	public void delete(String code) {
		// TODO Auto-generated method stub

	}

}
