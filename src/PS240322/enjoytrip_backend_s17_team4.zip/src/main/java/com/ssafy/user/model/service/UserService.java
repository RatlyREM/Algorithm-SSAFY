package com.ssafy.user.model.service;

public interface UserService {
	

}
