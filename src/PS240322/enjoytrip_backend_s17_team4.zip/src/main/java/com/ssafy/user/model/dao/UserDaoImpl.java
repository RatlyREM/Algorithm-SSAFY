package com.ssafy.user.model.dao;

import com.ssafy.util.DBUtil;

public class UserDaoImpl implements UserDao {

	private static UserDao dao = new UserDaoImpl();
	private DBUtil dbUtil;
	
	private UserDaoImpl() {
		dbUtil = DBUtil.getInstance();
	}
	
	public static UserDao getUserDao() {
		return dao;
	}
}
