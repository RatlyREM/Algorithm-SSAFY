package com.ssafy.user.model.service;

import com.ssafy.user.model.dao.UserDao;
import com.ssafy.user.model.dao.UserDaoImpl;

public class UserServiceImpl implements UserService {

	private static UserService service = new UserServiceImpl();
	private UserDao dao;
	
	private UserServiceImpl() {
		dao = UserDaoImpl.getUserDao();
	}
	
	public static UserService getUserService() {
		return service;
	}
}
