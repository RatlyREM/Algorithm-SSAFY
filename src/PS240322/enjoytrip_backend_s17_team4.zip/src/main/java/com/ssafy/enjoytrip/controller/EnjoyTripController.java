package com.ssafy.enjoytrip.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import jakarta.servlet.RequestDispatcher;

import com.ssafy.enjoytrip.model.EnjoyTripDto;
import com.ssafy.enjoytrip.model.service.EnjoyTripService;
import com.ssafy.enjoytrip.model.service.EnjoyTripServiceImpl;


@WebServlet("/Enjoy")

public class EnjoyTripController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private EnjoyTripService service;
	
	public void init() throws ServletException {
		super.init();
		service = EnjoyTripServiceImpl.getEnjoytripservice();
	}
	
    public EnjoyTripController() {
        super();
        // TODO Auto-generated constructor stub
    }
    

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		process(request, response);
	}
	
	private String list(HttpServletRequest request, HttpServletResponse response) {
		try {
			List<EnjoyTripDto> list = service.list(request.getParameter("search-area"), request.getParameter("search-content-id"), request.getParameter("search-keyword"));
			
			request.setAttribute("list", list);
			
			//return "/temp.jsp";
			return "/map/map.jsp";
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "/index.jsp";
		}
	}
	
	public void forward(HttpServletRequest request, HttpServletResponse response, String path) throws IOException, ServletException {
		RequestDispatcher dispatcher = request.getRequestDispatcher(path);
		dispatcher.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		process(request, response);
	}
	
	protected void process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = "";
		String action = request.getParameter("action");
		
		//System.out.println(request.getParameter("search-area") + " " + request.getParameter("search-content-id"));
		System.out.println(request.getParameter("search-keyword"));
		
		switch (action) {
//		case "mvjoin":
//			path= "/join.jsp";
//			//데이터를 안 싣고 갈 때 redirect
//			redirect(request, response, path);
//			
//			break;
//		case "join":
//			path= join(request, response);
//			
//			//db작업을 할 때 redirect로 하는 것이 간편함. 담아서 갈 거 아니면
//			redirect(request, response, path);
//			break;
		case "list":
			path= list(request, response);
			//데이터를 싣고 갈때 forward
			forward(request, response, path);
				
			break;
		}
	}
}
