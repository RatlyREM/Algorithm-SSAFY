package com.ssafy.enjoytrip.model.service;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.enjoytrip.model.EnjoyTripDto;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public interface EnjoyTripService {
	void regist(EnjoyTripDto enjoytripdto);
	List<EnjoyTripDto> list(String s1, String s2, String s3) throws Exception;
	EnjoyTripDto view(String code);
	void modify(EnjoyTripDto enjoytripdto);
	void delete(String code);
	
}
