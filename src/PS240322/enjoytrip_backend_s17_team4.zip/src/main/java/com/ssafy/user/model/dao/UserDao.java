package com.ssafy.user.model.dao;

public interface UserDao {

}
