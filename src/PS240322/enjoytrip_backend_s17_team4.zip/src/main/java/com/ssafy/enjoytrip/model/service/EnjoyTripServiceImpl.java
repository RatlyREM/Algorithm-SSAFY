package com.ssafy.enjoytrip.model.service;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.enjoytrip.model.EnjoyTripDto;
import com.ssafy.enjoytrip.model.dao.EnjoyTripDao;
import com.ssafy.enjoytrip.model.dao.EnjoyTripDaoImpl;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class EnjoyTripServiceImpl implements EnjoyTripService {
	
	private static EnjoyTripService enjoytripservice = new EnjoyTripServiceImpl();
	//Singleton
	
	private EnjoyTripDao dao;
	
	private EnjoyTripServiceImpl() {
		dao = EnjoyTripDaoImpl.getEnjoytripdao();
	}

	
	public static EnjoyTripService getEnjoytripservice() {
		return enjoytripservice;
	}


	public static void setEnjoytripservice(EnjoyTripService enjoytripservice) {
		EnjoyTripServiceImpl.enjoytripservice = enjoytripservice;
	}


	@Override
	public void regist(EnjoyTripDto enjoytripdto) {
		// TODO Auto-generated method stub

	}

	@Override
	public List<EnjoyTripDto> list(String s1, String s2, String s3) throws Exception {
		// TODO Auto-generated method stub
		return dao.list(s1, s2, s3);
	}
	
	@Override
	public EnjoyTripDto view(String code) {
		return null;
		// TODO Auto-generated method stub
	}

	@Override
	public void modify(EnjoyTripDto enjoytripdto) {
		// TODO Auto-generated method stub

	}

	@Override
	public void delete(String code) {
		// TODO Auto-generated method stub

	}

}
